<html>
    <head>
        <title>day1 typogrp</title>        
    </head>  
    <body background="Hydrangeas.jpg">
    <h1>header1</h1>
    <h2>header2</h2>
    <h3>header3</h3>
    <h4>header4</h4>
    <h5>header5</h5>
    <h6>header6</h6>
    <br>
    <hr>
    <a href="https://www.google.com/" target="_blank"="https://www.gmail.com/">google1</a>
    <a href="https://www.google.com/" target="_blank"="https://www.gmail.com/">google</a>
    <a href="https://www.gmail.com/" mailto="nensypatel17@gmail.com">gmail</a>
    <hr>
    <ol> 
        <li>item1</li>
        <li>item2</li>
        <li>item3</li>
        <li>item4</li>
    </ol>
    <hr>
    <ul>
        <li>item1</li>
        <li>item2</li>
        <li>item3</li>
        <li>item4</li>
    </ul>
</body>

</html>
