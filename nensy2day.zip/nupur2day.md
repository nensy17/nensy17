<!DOCTYPE html>
<html>
	<head>
		<title> TIME TABLE </title>
	</head>
	<body>
		<h1 align="center"> TIME TABLE </h1>
	<center>
	<table border=1 cellpadding=10px cellspacing=0>
		<tr>
			<th> Day/Period
			<th> I <br> 9:30-10:20
			<th> II <br> 10:20-11:10
			<th> III <br> 11:10-12:00
			<th> 12:00-12:40
			<th> VI <br> 12:40-1:30
 			<th> V <br> 1:30-:2:20
			<th> VI <br> 2:20-3:10
			<th> VII <br> 3:10-4:00
		</tr>
		<tr>
			<th> Monday
			<td> English
			<td> Math
			<td> Chemistry
			<td rowspan=5 align="center"> <b> L <br> U <br> N <br> C <br> H 
			<td colspan=3 align=center> Lab  
			<td> Physics
		</tr>
		<tr>
			<th> Tuesday
			<td colspan=3 align=center> Lab  
			<td> English
 			<td> Chemistry
			<td> Math
			<td> Sports
		</tr>
		<tr>
			<th> Wednesday
			<td> Physics
			<td> English
			<td> Chemistry
			<td> Chemistry
 			<td colspan=3 align=center> Library 
		</tr>
		<tr>
			<th> Thursday
			<td> Physics
			<td> English
			<td> Chemistry
			<td colspan=3 align=center> Lab   
			<td> Math
		</tr>
		<tr>
			<th> Friday
			<td colspan=3 align=center> Lab   
			<td> Math
 			<td> Chemistry
			<td> English
			<td> Physics
		</tr>
		<tr>
			<th> Saturday
			<td> English
			<td> Chemistry
			<td> Math
			<td colspan=3 align=center> Seminar 
			<td> Sports
		</tr>
	</table>
	</center>
	</body>
</html>